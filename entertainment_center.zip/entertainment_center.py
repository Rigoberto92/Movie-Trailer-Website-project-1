import fresh_tomatoes
import media

black_panther = media.Movie("Black Planther",
                "Half man, half panther, all king.",
                "https://upload.wikimedia.org/wikipedia/en/0/0c/Black_Panther_film_poster.jpg",
                "https://www.youtube.com/watch?v=xjDjIWPwcPU&t=1s")
print(black_panther.storyline)
                            
blade_runner_2049 = media.Movie("Blade Runner 2049",
                    "Bro it's Blade Runner but in 2049, need I say more?",
                    "https://upload.wikimedia.org/wikipedia/en/9/9b/Blade_Runner_2049_poster.png",
                    "https://www.youtube.com/watch?v=gCcx85zbxz4&t=3s")
print(blade_runner_2049.storyline)

doctor_strange = media.Movie("Doctor Strange",
                 "The world's greatest surgeon becomes the world's greatest sourcerer",
                 "https://upload.wikimedia.org/wikipedia/en/c/c7/Doctor_Strange_poster.jpg",
                 "https://www.youtube.com/watch?v=HSzx-zryEgM")
print(doctor_strange.storyline)

get_out = media.Movie("Get Out",
          "A seemingly innocent girlfriend invites her boyfriend to her creepy family's house, dude get out while you can!",
          "https://upload.wikimedia.org/wikipedia/en/e/eb/Teaser_poster_for_2017_film_Get_Out.png",
          "https://www.youtube.com/watch?v=JZoO1Ftj-bM&t=204s")
print(get_out.storyline)

jurassic_world = media.Movie("Jurassic World",
                 "Dino World bro, what could go wrong?!",
                 "https://upload.wikimedia.org/wikipedia/en/6/6e/Jurassic_World_poster.jpg",
                 "https://www.youtube.com/watch?v=d8tmJbaFuYM")
print(jurassic_world.storyline)

watchmen = media.Movie("Watchmen",
           "Super heroes minus the super powers...except for a shiny naked blue guy, he has really cool abilities.",
           "https://upload.wikimedia.org/wikipedia/en/b/bc/Watchmen_film_poster.jpg",
           "https://www.youtube.com/watch?v=NUjMO_k9IF8")
print(watchmen.storyline)
